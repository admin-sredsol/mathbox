export default /* glsl */ ``;
